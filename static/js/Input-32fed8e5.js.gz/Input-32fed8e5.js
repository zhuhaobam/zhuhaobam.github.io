import{a9 as ze,bD as nr,H as _,bK as tr,bL as ar,d as k,I as n,bM as lr,$ as b,a7 as y,a6 as s,aQ as ir,bN as sr,ab as _e,aW as cr,av as U,a8 as oe,aX as ur,a1 as dr,r as x,w as de,bO as hr,a0 as R,ak as H,a2 as fr,O as Se,bP as vr,aR as pr,ag as be,as as gr,bq as br,an as xe,a3 as xr,bF as mr,aN as ue,bQ as wr,a5 as yr,aV as J,P as Cr,R as zr,bR as _r,bv as me,az as we,ac as w,aA as ye}from"./main-91e7adf5.js";import{u as Sr}from"./use-merged-state-a6449094.js";function Ar(r){const{mergedLocaleRef:u,mergedDateLocaleRef:t}=ze(nr,null)||{},z=_(()=>{var d,c;return(c=(d=u==null?void 0:u.value)===null||d===void 0?void 0:d[r])!==null&&c!==void 0?c:tr[r]});return{dateLocaleRef:_(()=>{var d;return(d=t==null?void 0:t.value)!==null&&d!==void 0?d:ar}),localeRef:z}}const Rr=k({name:"Eye",render(){return n("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},n("path",{d:"M255.66 112c-77.94 0-157.89 45.11-220.83 135.33a16 16 0 0 0-.27 17.77C82.92 340.8 161.8 400 255.66 400c92.84 0 173.34-59.38 221.79-135.25a16.14 16.14 0 0 0 0-17.47C428.89 172.28 347.8 112 255.66 112z",fill:"none",stroke:"currentColor","stroke-linecap":"round","stroke-linejoin":"round","stroke-width":"32"}),n("circle",{cx:"256",cy:"256",r:"80",fill:"none",stroke:"currentColor","stroke-miterlimit":"10","stroke-width":"32"}))}}),Pr=k({name:"EyeOff",render(){return n("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},n("path",{d:"M432 448a15.92 15.92 0 0 1-11.31-4.69l-352-352a16 16 0 0 1 22.62-22.62l352 352A16 16 0 0 1 432 448z",fill:"currentColor"}),n("path",{d:"M255.66 384c-41.49 0-81.5-12.28-118.92-36.5c-34.07-22-64.74-53.51-88.7-91v-.08c19.94-28.57 41.78-52.73 65.24-72.21a2 2 0 0 0 .14-2.94L93.5 161.38a2 2 0 0 0-2.71-.12c-24.92 21-48.05 46.76-69.08 76.92a31.92 31.92 0 0 0-.64 35.54c26.41 41.33 60.4 76.14 98.28 100.65C162 402 207.9 416 255.66 416a239.13 239.13 0 0 0 75.8-12.58a2 2 0 0 0 .77-3.31l-21.58-21.58a4 4 0 0 0-3.83-1a204.8 204.8 0 0 1-51.16 6.47z",fill:"currentColor"}),n("path",{d:"M490.84 238.6c-26.46-40.92-60.79-75.68-99.27-100.53C349 110.55 302 96 255.66 96a227.34 227.34 0 0 0-74.89 12.83a2 2 0 0 0-.75 3.31l21.55 21.55a4 4 0 0 0 3.88 1a192.82 192.82 0 0 1 50.21-6.69c40.69 0 80.58 12.43 118.55 37c34.71 22.4 65.74 53.88 89.76 91a.13.13 0 0 1 0 .16a310.72 310.72 0 0 1-64.12 72.73a2 2 0 0 0-.15 2.95l19.9 19.89a2 2 0 0 0 2.7.13a343.49 343.49 0 0 0 68.64-78.48a32.2 32.2 0 0 0-.1-34.78z",fill:"currentColor"}),n("path",{d:"M256 160a95.88 95.88 0 0 0-21.37 2.4a2 2 0 0 0-1 3.38l112.59 112.56a2 2 0 0 0 3.38-1A96 96 0 0 0 256 160z",fill:"currentColor"}),n("path",{d:"M165.78 233.66a2 2 0 0 0-3.38 1a96 96 0 0 0 115 115a2 2 0 0 0 1-3.38z",fill:"currentColor"}))}}),Br=k({name:"ChevronDown",render(){return n("svg",{viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},n("path",{d:"M3.14645 5.64645C3.34171 5.45118 3.65829 5.45118 3.85355 5.64645L8 9.79289L12.1464 5.64645C12.3417 5.45118 12.6583 5.45118 12.8536 5.64645C13.0488 5.84171 13.0488 6.15829 12.8536 6.35355L8.35355 10.8536C8.15829 11.0488 7.84171 11.0488 7.64645 10.8536L3.14645 6.35355C2.95118 6.15829 2.95118 5.84171 3.14645 5.64645Z",fill:"currentColor"}))}}),Fr=lr("clear",n("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},n("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},n("g",{fill:"currentColor","fill-rule":"nonzero"},n("path",{d:"M8,2 C11.3137085,2 14,4.6862915 14,8 C14,11.3137085 11.3137085,14 8,14 C4.6862915,14 2,11.3137085 2,8 C2,4.6862915 4.6862915,2 8,2 Z M6.5343055,5.83859116 C6.33943736,5.70359511 6.07001296,5.72288026 5.89644661,5.89644661 L5.89644661,5.89644661 L5.83859116,5.9656945 C5.70359511,6.16056264 5.72288026,6.42998704 5.89644661,6.60355339 L5.89644661,6.60355339 L7.293,8 L5.89644661,9.39644661 L5.83859116,9.4656945 C5.70359511,9.66056264 5.72288026,9.92998704 5.89644661,10.1035534 L5.89644661,10.1035534 L5.9656945,10.1614088 C6.16056264,10.2964049 6.42998704,10.2771197 6.60355339,10.1035534 L6.60355339,10.1035534 L8,8.707 L9.39644661,10.1035534 L9.4656945,10.1614088 C9.66056264,10.2964049 9.92998704,10.2771197 10.1035534,10.1035534 L10.1035534,10.1035534 L10.1614088,10.0343055 C10.2964049,9.83943736 10.2771197,9.57001296 10.1035534,9.39644661 L10.1035534,9.39644661 L8.707,8 L10.1035534,6.60355339 L10.1614088,6.5343055 C10.2964049,6.33943736 10.2771197,6.07001296 10.1035534,5.89644661 L10.1035534,5.89644661 L10.0343055,5.83859116 C9.83943736,5.70359511 9.57001296,5.72288026 9.39644661,5.89644661 L9.39644661,5.89644661 L8,7.293 L6.60355339,5.89644661 Z"}))))),$r=b("base-clear",`
 flex-shrink: 0;
 height: 1em;
 width: 1em;
 position: relative;
`,[y(">",[s("clear",`
 font-size: var(--n-clear-size);
 height: 1em;
 width: 1em;
 cursor: pointer;
 color: var(--n-clear-color);
 transition: color .3s var(--n-bezier);
 display: flex;
 `,[y("&:hover",`
 color: var(--n-clear-color-hover)!important;
 `),y("&:active",`
 color: var(--n-clear-color-pressed)!important;
 `)]),s("placeholder",`
 display: flex;
 `),s("clear, placeholder",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 `,[ir({originalTransform:"translateX(-50%) translateY(-50%)",left:"50%",top:"50%"})])])]),he=k({name:"BaseClear",props:{clsPrefix:{type:String,required:!0},show:Boolean,onClear:Function},setup(r){return sr("-base-clear",$r,_e(r,"clsPrefix")),{handleMouseDown(u){u.preventDefault()}}},render(){const{clsPrefix:r}=this;return n("div",{class:`${r}-base-clear`},n(cr,null,{default:()=>{var u,t;return this.show?n("div",{key:"dismiss",class:`${r}-base-clear__clear`,onClick:this.onClear,onMousedown:this.handleMouseDown,"data-clear":!0},U(this.$slots.icon,()=>[n(oe,{clsPrefix:r},{default:()=>n(Fr,null)})])):n("div",{key:"icon",class:`${r}-base-clear__placeholder`},(t=(u=this.$slots).placeholder)===null||t===void 0?void 0:t.call(u))}}))}}),Er=k({name:"InternalSelectionSuffix",props:{clsPrefix:{type:String,required:!0},showArrow:{type:Boolean,default:void 0},showClear:{type:Boolean,default:void 0},loading:{type:Boolean,default:!1},onClear:Function},setup(r,{slots:u}){return()=>{const{clsPrefix:t}=r;return n(ur,{clsPrefix:t,class:`${t}-base-suffix`,strokeWidth:24,scale:.85,show:r.loading},{default:()=>r.showArrow?n(he,{clsPrefix:t,show:r.showClear,onClear:r.onClear},{placeholder:()=>n(oe,{clsPrefix:t,class:`${t}-base-suffix__arrow`},{default:()=>U(u.default,()=>[n(Br,null)])})}):null})}}}),Ae=dr("n-input");function kr(r){let u=0;for(const t of r)u++;return u}function ee(r){return r===""||r==null}function Ir(r){const u=x(null);function t(){const{value:d}=r;if(!d||!d.focus){S();return}const{selectionStart:c,selectionEnd:l,value:i}=d;if(c==null||l==null){S();return}u.value={start:c,end:l,beforeText:i.slice(0,c),afterText:i.slice(l)}}function z(){var d;const{value:c}=u,{value:l}=r;if(!c||!l)return;const{value:i}=l,{start:h,beforeText:f,afterText:m}=c;let C=i.length;if(i.endsWith(m))C=i.length-m.length;else if(i.startsWith(f))C=f.length;else{const j=f[h-1],A=i.indexOf(j,h-1);A!==-1&&(C=A+1)}(d=l.setSelectionRange)===null||d===void 0||d.call(l,C,C)}function S(){u.value=null}return de(r,S),{recordCursor:t,restoreCursor:z}}const Ce=k({name:"InputWordCount",setup(r,{slots:u}){const{mergedValueRef:t,maxlengthRef:z,mergedClsPrefixRef:S}=ze(Ae),d=_(()=>{const{value:c}=t;return c===null||Array.isArray(c)?0:kr(c)});return()=>{const{value:c}=z,{value:l}=t;return n("span",{class:`${S.value}-input-word-count`},hr(u.default,{value:l===null||Array.isArray(l)?"":l},()=>[c===void 0?d.value:`${d.value} / ${c}`]))}}}),Tr=b("input",`
 max-width: 100%;
 cursor: text;
 line-height: 1.5;
 z-index: auto;
 outline: none;
 box-sizing: border-box;
 position: relative;
 display: inline-flex;
 border-radius: var(--n-border-radius);
 background-color: var(--n-color);
 transition: background-color .3s var(--n-bezier);
 font-size: var(--n-font-size);
 --n-padding-vertical: calc((var(--n-height) - 1.5 * var(--n-font-size)) / 2);
`,[s("input, textarea",`
 overflow: hidden;
 flex-grow: 1;
 position: relative;
 `),s("input-el, textarea-el, input-mirror, textarea-mirror, separator, placeholder",`
 box-sizing: border-box;
 font-size: inherit;
 line-height: 1.5;
 font-family: inherit;
 border: none;
 outline: none;
 background-color: #0000;
 text-align: inherit;
 transition:
 -webkit-text-fill-color .3s var(--n-bezier),
 caret-color .3s var(--n-bezier),
 color .3s var(--n-bezier),
 text-decoration-color .3s var(--n-bezier);
 `),s("input-el, textarea-el",`
 -webkit-appearance: none;
 scrollbar-width: none;
 width: 100%;
 min-width: 0;
 text-decoration-color: var(--n-text-decoration-color);
 color: var(--n-text-color);
 caret-color: var(--n-caret-color);
 background-color: transparent;
 `,[y("&::-webkit-scrollbar, &::-webkit-scrollbar-track-piece, &::-webkit-scrollbar-thumb",`
 width: 0;
 height: 0;
 display: none;
 `),y("&::placeholder","color: #0000;"),y("&:-webkit-autofill ~",[s("placeholder","display: none;")])]),R("round",[H("textarea","border-radius: calc(var(--n-height) / 2);")]),s("placeholder",`
 pointer-events: none;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 overflow: hidden;
 color: var(--n-placeholder-color);
 `,[y("span",`
 width: 100%;
 display: inline-block;
 `)]),R("textarea",[s("placeholder","overflow: visible;")]),H("autosize","width: 100%;"),R("autosize",[s("textarea-el, input-el",`
 position: absolute;
 top: 0;
 left: 0;
 height: 100%;
 `)]),b("input-wrapper",`
 overflow: hidden;
 display: inline-flex;
 flex-grow: 1;
 position: relative;
 padding-left: var(--n-padding-left);
 padding-right: var(--n-padding-right);
 `),s("input-mirror",`
 padding: 0;
 height: var(--n-height);
 overflow: hidden;
 visibility: hidden;
 position: static;
 white-space: nowrap;
 pointer-events: none;
 `),s("input-el",`
 padding: 0;
 height: var(--n-height);
 line-height: var(--n-height);
 `,[y("+",[s("placeholder",`
 display: flex;
 align-items: center; 
 `)])]),H("textarea",[s("placeholder","white-space: nowrap;")]),s("eye",`
 transition: color .3s var(--n-bezier);
 `),R("textarea","width: 100%;",[b("input-word-count",`
 position: absolute;
 right: var(--n-padding-right);
 bottom: var(--n-padding-vertical);
 `),R("resizable",[b("input-wrapper",`
 resize: vertical;
 min-height: var(--n-height);
 `)]),s("textarea-el, textarea-mirror, placeholder",`
 height: 100%;
 padding-left: 0;
 padding-right: 0;
 padding-top: var(--n-padding-vertical);
 padding-bottom: var(--n-padding-vertical);
 word-break: break-word;
 display: inline-block;
 vertical-align: bottom;
 box-sizing: border-box;
 line-height: var(--n-line-height-textarea);
 margin: 0;
 resize: none;
 white-space: pre-wrap;
 `),s("textarea-mirror",`
 width: 100%;
 pointer-events: none;
 overflow: hidden;
 visibility: hidden;
 position: static;
 white-space: pre-wrap;
 overflow-wrap: break-word;
 `)]),R("pair",[s("input-el, placeholder","text-align: center;"),s("separator",`
 display: flex;
 align-items: center;
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
 white-space: nowrap;
 `,[b("icon",`
 color: var(--n-icon-color);
 `),b("base-icon",`
 color: var(--n-icon-color);
 `)])]),R("disabled",`
 cursor: not-allowed;
 background-color: var(--n-color-disabled);
 `,[s("border","border: var(--n-border-disabled);"),s("input-el, textarea-el",`
 cursor: not-allowed;
 color: var(--n-text-color-disabled);
 text-decoration-color: var(--n-text-color-disabled);
 -webkit-text-fill-color: var(--n-text-color-disabled);
 `),s("placeholder","color: var(--n-placeholder-color-disabled);"),s("separator","color: var(--n-text-color-disabled);",[b("icon",`
 color: var(--n-icon-color-disabled);
 `),b("base-icon",`
 color: var(--n-icon-color-disabled);
 `)]),s("suffix, prefix","color: var(--n-text-color-disabled);",[b("icon",`
 color: var(--n-icon-color-disabled);
 `),b("internal-icon",`
 color: var(--n-icon-color-disabled);
 `)])]),H("disabled",[s("eye",`
 display: flex;
 align-items: center;
 justify-content: center;
 color: var(--n-icon-color);
 cursor: pointer;
 `,[y("&:hover",`
 color: var(--n-icon-color-hover);
 `),y("&:active",`
 color: var(--n-icon-color-pressed);
 `)]),y("&:hover",[s("state-border","border: var(--n-border-hover);")]),R("focus","background-color: var(--n-color-focus);",[s("state-border",`
 border: var(--n-border-focus);
 box-shadow: var(--n-box-shadow-focus);
 `)])]),s("border, state-border",`
 box-sizing: border-box;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border-radius: inherit;
 border: var(--n-border);
 transition:
 box-shadow .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `),s("state-border",`
 border-color: #0000;
 z-index: 1;
 `),s("prefix","margin-right: 4px;"),s("suffix",`
 margin-left: 4px;
 `),s("suffix, prefix",`
 transition: color .3s var(--n-bezier);
 flex-wrap: nowrap;
 flex-shrink: 0;
 line-height: var(--n-height);
 white-space: nowrap;
 display: inline-flex;
 align-items: center;
 justify-content: center;
 color: var(--n-suffix-text-color);
 `,[b("base-loading",`
 font-size: var(--n-icon-size);
 margin: 0 2px;
 color: var(--n-loading-color);
 `),b("base-clear",`
 font-size: var(--n-icon-size);
 `,[s("placeholder",[b("base-icon",`
 transition: color .3s var(--n-bezier);
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 `)])]),y(">",[b("icon",`
 transition: color .3s var(--n-bezier);
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 `)]),b("base-icon",`
 font-size: var(--n-icon-size);
 `)]),b("input-word-count",`
 pointer-events: none;
 line-height: 1.5;
 font-size: .85em;
 color: var(--n-count-text-color);
 transition: color .3s var(--n-bezier);
 margin-left: 4px;
 font-variant: tabular-nums;
 `),["warning","error"].map(r=>R(`${r}-status`,[H("disabled",[b("base-loading",`
 color: var(--n-loading-color-${r})
 `),s("input-el, textarea-el",`
 caret-color: var(--n-caret-color-${r});
 `),s("state-border",`
 border: var(--n-border-${r});
 `),y("&:hover",[s("state-border",`
 border: var(--n-border-hover-${r});
 `)]),y("&:focus",`
 background-color: var(--n-color-focus-${r});
 `,[s("state-border",`
 box-shadow: var(--n-box-shadow-focus-${r});
 border: var(--n-border-focus-${r});
 `)]),R("focus",`
 background-color: var(--n-color-focus-${r});
 `,[s("state-border",`
 box-shadow: var(--n-box-shadow-focus-${r});
 border: var(--n-border-focus-${r});
 `)])])]))]),Mr=Object.assign(Object.assign({},Se.props),{bordered:{type:Boolean,default:void 0},type:{type:String,default:"text"},placeholder:[Array,String],defaultValue:{type:[String,Array],default:null},value:[String,Array],disabled:{type:Boolean,default:void 0},size:String,rows:{type:[Number,String],default:3},round:Boolean,minlength:[String,Number],maxlength:[String,Number],clearable:Boolean,autosize:{type:[Boolean,Object],default:!1},pair:Boolean,separator:String,readonly:{type:[String,Boolean],default:!1},passivelyActivated:Boolean,showPasswordOn:String,stateful:{type:Boolean,default:!0},autofocus:Boolean,inputProps:Object,resizable:{type:Boolean,default:!0},showCount:Boolean,loading:{type:Boolean,default:void 0},allowInput:Function,onMousedown:Function,onKeydown:Function,onKeyup:Function,onInput:[Function,Array],onFocus:[Function,Array],onBlur:[Function,Array],onClick:[Function,Array],onChange:[Function,Array],onClear:[Function,Array],status:String,"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],textDecoration:[String,Array],attrSize:{type:Number,default:20},onInputBlur:[Function,Array],onInputFocus:[Function,Array],onDeactivate:[Function,Array],onActivate:[Function,Array],onWrapperFocus:[Function,Array],onWrapperBlur:[Function,Array],internalDeactivateOnEnter:Boolean,internalForceFocus:Boolean,internalLoadingBeforeSuffix:Boolean,showPasswordToggle:Boolean}),Vr=k({name:"Input",props:Mr,setup(r){const{mergedClsPrefixRef:u,mergedBorderedRef:t,inlineThemeDisabled:z,mergedRtlRef:S}=fr(r),d=Se("Input","-input",Tr,vr,r,u),c=x(null),l=x(null),i=x(null),h=x(null),f=x(null),m=x(null),C=x(null),j=Ir(C),A=x(null),{localeRef:Re}=Ar("Input"),K=x(r.defaultValue),Pe=_e(r,"value"),P=Sr(Pe,K),L=pr(r),{mergedSizeRef:re,mergedDisabledRef:I,mergedStatusRef:Be}=L,T=x(!1),D=x(!1),B=x(!1),V=x(!1);let ne=null;const te=_(()=>{const{placeholder:e,pair:o}=r;return o?Array.isArray(e)?e:e===void 0?["",""]:[e,e]:e===void 0?[Re.value.placeholder]:[e]}),Fe=_(()=>{const{value:e}=B,{value:o}=P,{value:a}=te;return!e&&(ee(o)||Array.isArray(o)&&ee(o[0]))&&a[0]}),$e=_(()=>{const{value:e}=B,{value:o}=P,{value:a}=te;return!e&&a[1]&&(ee(o)||Array.isArray(o)&&ee(o[1]))}),ae=be(()=>r.internalForceFocus||T.value),Ee=be(()=>{if(I.value||r.readonly||!r.clearable||!ae.value&&!D.value)return!1;const{value:e}=P,{value:o}=ae;return r.pair?!!(Array.isArray(e)&&(e[0]||e[1]))&&(D.value||o):!!e&&(D.value||o)}),le=_(()=>{const{showPasswordOn:e}=r;if(e)return e;if(r.showPasswordToggle)return"click"}),W=x(!1),ke=_(()=>{const{textDecoration:e}=r;return e?Array.isArray(e)?e.map(o=>({textDecoration:o})):[{textDecoration:e}]:["",""]}),fe=x(void 0),Ie=()=>{var e,o;if(r.type==="textarea"){const{autosize:a}=r;if(a&&(fe.value=(o=(e=A.value)===null||e===void 0?void 0:e.$el)===null||o===void 0?void 0:o.offsetWidth),!l.value||typeof a=="boolean")return;const{paddingTop:v,paddingBottom:p,lineHeight:g}=window.getComputedStyle(l.value),F=Number(v.slice(0,-2)),$=Number(p.slice(0,-2)),E=Number(g.slice(0,-2)),{value:O}=i;if(!O)return;if(a.minRows){const N=Math.max(a.minRows,1),ce=`${F+$+E*N}px`;O.style.minHeight=ce}if(a.maxRows){const N=`${F+$+E*a.maxRows}px`;O.style.maxHeight=N}}},Te=_(()=>{const{maxlength:e}=r;return e===void 0?void 0:Number(e)});gr(()=>{const{value:e}=P;Array.isArray(e)||se(e)});const Me=br().proxy;function Y(e){const{onUpdateValue:o,"onUpdate:value":a,onInput:v}=r,{nTriggerFormInput:p}=L;o&&w(o,e),a&&w(a,e),v&&w(v,e),K.value=e,p()}function X(e){const{onChange:o}=r,{nTriggerFormChange:a}=L;o&&w(o,e),K.value=e,a()}function Le(e){const{onBlur:o}=r,{nTriggerFormBlur:a}=L;o&&w(o,e),a()}function De(e){const{onFocus:o}=r,{nTriggerFormFocus:a}=L;o&&w(o,e),a()}function Ve(e){const{onClear:o}=r;o&&w(o,e)}function We(e){const{onInputBlur:o}=r;o&&w(o,e)}function Oe(e){const{onInputFocus:o}=r;o&&w(o,e)}function Ne(){const{onDeactivate:e}=r;e&&w(e)}function He(){const{onActivate:e}=r;e&&w(e)}function Ue(e){const{onClick:o}=r;o&&w(o,e)}function je(e){const{onWrapperFocus:o}=r;o&&w(o,e)}function Ke(e){const{onWrapperBlur:o}=r;o&&w(o,e)}function Ye(){B.value=!0}function Xe(e){B.value=!1,e.target===m.value?q(e,1):q(e,0)}function q(e,o=0,a="input"){const v=e.target.value;if(se(v),r.type==="textarea"){const{value:g}=A;g&&g.syncUnifiedContainer()}if(ne=v,B.value)return;j.recordCursor();const p=qe(v);if(p)if(!r.pair)a==="input"?Y(v):X(v);else{let{value:g}=P;Array.isArray(g)?g=[g[0],g[1]]:g=["",""],g[o]=v,a==="input"?Y(g):X(g)}Me.$forceUpdate(),p||me(j.restoreCursor)}function qe(e){const{allowInput:o}=r;return typeof o=="function"?o(e):!0}function Ze(e){We(e),e.relatedTarget===c.value&&Ne(),e.relatedTarget!==null&&(e.relatedTarget===f.value||e.relatedTarget===m.value||e.relatedTarget===l.value)||(V.value=!1),Z(e,"blur"),C.value=null}function Qe(e,o){Oe(e),T.value=!0,V.value=!0,He(),Z(e,"focus"),o===0?C.value=f.value:o===1?C.value=m.value:o===2&&(C.value=l.value)}function Ge(e){r.passivelyActivated&&(Ke(e),Z(e,"blur"))}function Je(e){r.passivelyActivated&&(T.value=!0,je(e),Z(e,"focus"))}function Z(e,o){e.relatedTarget!==null&&(e.relatedTarget===f.value||e.relatedTarget===m.value||e.relatedTarget===l.value||e.relatedTarget===c.value)||(o==="focus"?(De(e),T.value=!0):o==="blur"&&(Le(e),T.value=!1))}function eo(e,o){q(e,o,"change")}function oo(e){Ue(e)}function ro(e){Ve(e),r.pair?(Y(["",""]),X(["",""])):(Y(""),X(""))}function no(e){const{onMousedown:o}=r;o&&o(e);const{tagName:a}=e.target;if(a!=="INPUT"&&a!=="TEXTAREA"){if(r.resizable){const{value:v}=c;if(v){const{left:p,top:g,width:F,height:$}=v.getBoundingClientRect(),E=14;if(p+F-E<e.clientX&&e.clientY<p+F&&g+$-E<e.clientY&&e.clientY<g+$)return}}e.preventDefault(),T.value||ve()}}function to(){var e;D.value=!0,r.type==="textarea"&&((e=A.value)===null||e===void 0||e.handleMouseEnterWrapper())}function ao(){var e;D.value=!1,r.type==="textarea"&&((e=A.value)===null||e===void 0||e.handleMouseLeaveWrapper())}function lo(){I.value||le.value==="click"&&(W.value=!W.value)}function io(e){if(I.value)return;e.preventDefault();const o=v=>{v.preventDefault(),ye("mouseup",document,o)};if(we("mouseup",document,o),le.value!=="mousedown")return;W.value=!0;const a=()=>{W.value=!1,ye("mouseup",document,a)};we("mouseup",document,a)}function so(e){var o;switch((o=r.onKeydown)===null||o===void 0||o.call(r,e),e.key){case"Escape":ie();break;case"Enter":co(e);break}}function co(e){var o,a;if(r.passivelyActivated){const{value:v}=V;if(v){r.internalDeactivateOnEnter&&ie();return}e.preventDefault(),r.type==="textarea"?(o=l.value)===null||o===void 0||o.focus():(a=f.value)===null||a===void 0||a.focus()}}function ie(){r.passivelyActivated&&(V.value=!1,me(()=>{var e;(e=c.value)===null||e===void 0||e.focus()}))}function ve(){var e,o,a;I.value||(r.passivelyActivated?(e=c.value)===null||e===void 0||e.focus():((o=l.value)===null||o===void 0||o.focus(),(a=f.value)===null||a===void 0||a.focus()))}function uo(){var e;!((e=c.value)===null||e===void 0)&&e.contains(document.activeElement)&&document.activeElement.blur()}function ho(){var e,o;(e=l.value)===null||e===void 0||e.select(),(o=f.value)===null||o===void 0||o.select()}function fo(){I.value||(l.value?l.value.focus():f.value&&f.value.focus())}function vo(){const{value:e}=c;(e==null?void 0:e.contains(document.activeElement))&&e!==document.activeElement&&ie()}function po(e){if(r.type==="textarea"){const{value:o}=l;o==null||o.scrollTo(e)}else{const{value:o}=f;o==null||o.scrollTo(e)}}function se(e){const{type:o,pair:a,autosize:v}=r;if(!a&&v)if(o==="textarea"){const{value:p}=i;p&&(p.textContent=(e!=null?e:"")+`\r
`)}else{const{value:p}=h;p&&(e?p.textContent=e:p.innerHTML="&nbsp;")}}function go(){Ie()}const pe=x({top:"0"});function bo(e){var o;const{scrollTop:a}=e.target;pe.value.top=`${-a}px`,(o=A.value)===null||o===void 0||o.syncUnifiedContainer()}let Q=null;xe(()=>{const{autosize:e,type:o}=r;e&&o==="textarea"?Q=de(P,a=>{!Array.isArray(a)&&a!==ne&&se(a)}):Q==null||Q()});let G=null;xe(()=>{r.type==="textarea"?G=de(P,e=>{var o;!Array.isArray(e)&&e!==ne&&((o=A.value)===null||o===void 0||o.syncUnifiedContainer())}):G==null||G()}),xr(Ae,{mergedValueRef:P,maxlengthRef:Te,mergedClsPrefixRef:u});const xo={wrapperElRef:c,inputElRef:f,textareaElRef:l,isCompositing:B,focus:ve,blur:uo,select:ho,deactivate:vo,activate:fo,scrollTo:po},mo=mr("Input",S,u),ge=_(()=>{const{value:e}=re,{common:{cubicBezierEaseInOut:o},self:{color:a,borderRadius:v,textColor:p,caretColor:g,caretColorError:F,caretColorWarning:$,textDecorationColor:E,border:O,borderDisabled:N,borderHover:ce,borderFocus:wo,placeholderColor:yo,placeholderColorDisabled:Co,lineHeightTextarea:zo,colorDisabled:_o,colorFocus:So,textColorDisabled:Ao,boxShadowFocus:Ro,iconSize:Po,colorFocusWarning:Bo,boxShadowFocusWarning:Fo,borderWarning:$o,borderFocusWarning:Eo,borderHoverWarning:ko,colorFocusError:Io,boxShadowFocusError:To,borderError:Mo,borderFocusError:Lo,borderHoverError:Do,clearSize:Vo,clearColor:Wo,clearColorHover:Oo,clearColorPressed:No,iconColor:Ho,iconColorDisabled:Uo,suffixTextColor:jo,countTextColor:Ko,iconColorHover:Yo,iconColorPressed:Xo,loadingColor:qo,loadingColorError:Zo,loadingColorWarning:Qo,[ue("padding",e)]:Go,[ue("fontSize",e)]:Jo,[ue("height",e)]:er}}=d.value,{left:or,right:rr}=wr(Go);return{"--n-bezier":o,"--n-count-text-color":Ko,"--n-color":a,"--n-font-size":Jo,"--n-border-radius":v,"--n-height":er,"--n-padding-left":or,"--n-padding-right":rr,"--n-text-color":p,"--n-caret-color":g,"--n-text-decoration-color":E,"--n-border":O,"--n-border-disabled":N,"--n-border-hover":ce,"--n-border-focus":wo,"--n-placeholder-color":yo,"--n-placeholder-color-disabled":Co,"--n-icon-size":Po,"--n-line-height-textarea":zo,"--n-color-disabled":_o,"--n-color-focus":So,"--n-text-color-disabled":Ao,"--n-box-shadow-focus":Ro,"--n-loading-color":qo,"--n-caret-color-warning":$,"--n-color-focus-warning":Bo,"--n-box-shadow-focus-warning":Fo,"--n-border-warning":$o,"--n-border-focus-warning":Eo,"--n-border-hover-warning":ko,"--n-loading-color-warning":Qo,"--n-caret-color-error":F,"--n-color-focus-error":Io,"--n-box-shadow-focus-error":To,"--n-border-error":Mo,"--n-border-focus-error":Lo,"--n-border-hover-error":Do,"--n-loading-color-error":Zo,"--n-clear-color":Wo,"--n-clear-size":Vo,"--n-clear-color-hover":Oo,"--n-clear-color-pressed":No,"--n-icon-color":Ho,"--n-icon-color-hover":Yo,"--n-icon-color-pressed":Xo,"--n-icon-color-disabled":Uo,"--n-suffix-text-color":jo}}),M=z?yr("input",_(()=>{const{value:e}=re;return e[0]}),ge,r):void 0;return Object.assign(Object.assign({},xo),{wrapperElRef:c,inputElRef:f,inputMirrorElRef:h,inputEl2Ref:m,textareaElRef:l,textareaMirrorElRef:i,textareaScrollbarInstRef:A,rtlEnabled:mo,uncontrolledValue:K,mergedValue:P,passwordVisible:W,mergedPlaceholder:te,showPlaceholder1:Fe,showPlaceholder2:$e,mergedFocus:ae,isComposing:B,activated:V,showClearButton:Ee,mergedSize:re,mergedDisabled:I,textDecorationStyle:ke,mergedClsPrefix:u,mergedBordered:t,mergedShowPasswordOn:le,placeholderStyle:pe,mergedStatus:Be,textAreaScrollContainerWidth:fe,handleTextAreaScroll:bo,handleCompositionStart:Ye,handleCompositionEnd:Xe,handleInput:q,handleInputBlur:Ze,handleInputFocus:Qe,handleWrapperBlur:Ge,handleWrapperFocus:Je,handleMouseEnter:to,handleMouseLeave:ao,handleMouseDown:no,handleChange:eo,handleClick:oo,handleClear:ro,handlePasswordToggleClick:lo,handlePasswordToggleMousedown:io,handleWrapperKeydown:so,handleTextAreaMirrorResize:go,getTextareaScrollContainer:()=>l.value,mergedTheme:d,cssVars:z?void 0:ge,themeClass:M==null?void 0:M.themeClass,onRender:M==null?void 0:M.onRender})},render(){var r,u;const{mergedClsPrefix:t,mergedStatus:z,themeClass:S,type:d,onRender:c}=this,l=this.$slots;return c==null||c(),n("div",{ref:"wrapperElRef",class:[`${t}-input`,S,z&&`${t}-input--${z}-status`,{[`${t}-input--rtl`]:this.rtlEnabled,[`${t}-input--disabled`]:this.mergedDisabled,[`${t}-input--textarea`]:d==="textarea",[`${t}-input--resizable`]:this.resizable&&!this.autosize,[`${t}-input--autosize`]:this.autosize,[`${t}-input--round`]:this.round&&d!=="textarea",[`${t}-input--pair`]:this.pair,[`${t}-input--focus`]:this.mergedFocus,[`${t}-input--stateful`]:this.stateful}],style:this.cssVars,tabindex:!this.mergedDisabled&&this.passivelyActivated&&!this.activated?0:void 0,onFocus:this.handleWrapperFocus,onBlur:this.handleWrapperBlur,onClick:this.handleClick,onMousedown:this.handleMouseDown,onMouseenter:this.handleMouseEnter,onMouseleave:this.handleMouseLeave,onCompositionstart:this.handleCompositionStart,onCompositionend:this.handleCompositionEnd,onKeyup:this.onKeyup,onKeydown:this.handleWrapperKeydown},n("div",{class:`${t}-input-wrapper`},J(l.prefix,i=>i&&n("div",{class:`${t}-input__prefix`},i)),d==="textarea"?n(Cr,{ref:"textareaScrollbarInstRef",class:`${t}-input__textarea`,container:this.getTextareaScrollContainer,triggerDisplayManually:!0,useUnifiedContainer:!0,internalHoistYRail:!0},{default:()=>{var i,h;const{textAreaScrollContainerWidth:f}=this,m={width:this.autosize&&f&&`${f}px`};return n(zr,null,n("textarea",Object.assign({},this.inputProps,{ref:"textareaElRef",class:[`${t}-input__textarea-el`,(i=this.inputProps)===null||i===void 0?void 0:i.class],autofocus:this.autofocus,rows:Number(this.rows),placeholder:this.placeholder,value:this.mergedValue,disabled:this.mergedDisabled,maxlength:this.maxlength,minlength:this.minlength,readonly:this.readonly,tabindex:this.passivelyActivated&&!this.activated?-1:void 0,style:[this.textDecorationStyle[0],(h=this.inputProps)===null||h===void 0?void 0:h.style,m],onBlur:this.handleInputBlur,onFocus:C=>this.handleInputFocus(C,2),onInput:this.handleInput,onChange:this.handleChange,onScroll:this.handleTextAreaScroll})),this.showPlaceholder1?n("div",{class:`${t}-input__placeholder`,style:[this.placeholderStyle,m],key:"placeholder"},this.mergedPlaceholder[0]):null,this.autosize?n(_r,{onResize:this.handleTextAreaMirrorResize},{default:()=>n("div",{ref:"textareaMirrorElRef",class:`${t}-input__textarea-mirror`,key:"mirror"})}):null)}}):n("div",{class:`${t}-input__input`},n("input",Object.assign({type:d==="password"&&this.mergedShowPasswordOn&&this.passwordVisible?"text":d},this.inputProps,{ref:"inputElRef",class:[`${t}-input__input-el`,(r=this.inputProps)===null||r===void 0?void 0:r.class],style:[this.textDecorationStyle[0],(u=this.inputProps)===null||u===void 0?void 0:u.style],tabindex:this.passivelyActivated&&!this.activated?-1:void 0,placeholder:this.mergedPlaceholder[0],disabled:this.mergedDisabled,maxlength:this.maxlength,minlength:this.minlength,value:Array.isArray(this.mergedValue)?this.mergedValue[0]:this.mergedValue,readonly:this.readonly,autofocus:this.autofocus,size:this.attrSize,onBlur:this.handleInputBlur,onFocus:i=>this.handleInputFocus(i,0),onInput:i=>this.handleInput(i,0),onChange:i=>this.handleChange(i,0)})),this.showPlaceholder1?n("div",{class:`${t}-input__placeholder`},n("span",null,this.mergedPlaceholder[0])):null,this.autosize?n("div",{class:`${t}-input__input-mirror`,key:"mirror",ref:"inputMirrorElRef"},"\xA0"):null),!this.pair&&J(l.suffix,i=>i||this.clearable||this.showCount||this.mergedShowPasswordOn||this.loading!==void 0?n("div",{class:`${t}-input__suffix`},[J(l["clear-icon-placeholder"],h=>(this.clearable||h)&&n(he,{clsPrefix:t,show:this.showClearButton,onClear:this.handleClear},{placeholder:()=>h,icon:()=>{var f,m;return(m=(f=this.$slots)["clear-icon"])===null||m===void 0?void 0:m.call(f)}})),this.internalLoadingBeforeSuffix?null:i,this.loading!==void 0?n(Er,{clsPrefix:t,loading:this.loading,showArrow:!1,showClear:!1,style:this.cssVars}):null,this.internalLoadingBeforeSuffix?i:null,this.showCount&&this.type!=="textarea"?n(Ce,null,{default:h=>{var f;return(f=l.count)===null||f===void 0?void 0:f.call(l,h)}}):null,this.mergedShowPasswordOn&&this.type==="password"?n("div",{class:`${t}-input__eye`,onMousedown:this.handlePasswordToggleMousedown,onClick:this.handlePasswordToggleClick},this.passwordVisible?U(l["password-visible-icon"],()=>[n(oe,{clsPrefix:t},{default:()=>n(Rr,null)})]):U(l["password-invisible-icon"],()=>[n(oe,{clsPrefix:t},{default:()=>n(Pr,null)})])):null]):null)),this.pair?n("span",{class:`${t}-input__separator`},U(l.separator,()=>[this.separator])):null,this.pair?n("div",{class:`${t}-input-wrapper`},n("div",{class:`${t}-input__input`},n("input",{ref:"inputEl2Ref",type:this.type,class:`${t}-input__input-el`,tabindex:this.passivelyActivated&&!this.activated?-1:void 0,placeholder:this.mergedPlaceholder[1],disabled:this.mergedDisabled,maxlength:this.maxlength,minlength:this.minlength,value:Array.isArray(this.mergedValue)?this.mergedValue[1]:void 0,readonly:this.readonly,style:this.textDecorationStyle[1],onBlur:this.handleInputBlur,onFocus:i=>this.handleInputFocus(i,1),onInput:i=>this.handleInput(i,1),onChange:i=>this.handleChange(i,1)}),this.showPlaceholder2?n("div",{class:`${t}-input__placeholder`},n("span",null,this.mergedPlaceholder[1])):null),J(l.suffix,i=>(this.clearable||i)&&n("div",{class:`${t}-input__suffix`},[this.clearable&&n(he,{clsPrefix:t,show:this.showClearButton,onClear:this.handleClear},{icon:()=>{var h;return(h=l["clear-icon"])===null||h===void 0?void 0:h.call(l)},placeholder:()=>{var h;return(h=l["clear-icon-placeholder"])===null||h===void 0?void 0:h.call(l)}}),i]))):null,this.mergedBordered?n("div",{class:`${t}-input__border`}):null,this.mergedBordered?n("div",{class:`${t}-input__state-border`}):null,this.showCount&&d==="textarea"?n(Ce,null,{default:i=>{var h;return(h=l.count)===null||h===void 0?void 0:h.call(l,i)}}):null)}});export{Vr as _,Ar as u};
